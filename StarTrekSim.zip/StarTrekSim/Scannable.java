/**
 * Represents objects you are able to scan with your detailed sensors
 * I did not collaborate on this assignment
 * @author Sabrina Seibel
 * @version 1.0
 */
public interface Scannable {
    /**
    * This method returns the Object's id and a description of it
    * @return String representation of id and description
    */
    String scanned();
}
import java.util.Random;
/**
 * Represents an Asteroid object
 * I did not collaborate on this assignment
 * @author Sabrina Seibel
 * @version 1.0
 */
public class Asteroid extends AstronomicalObject implements Attackable,
    Embarkable, Scannable {
    /**
    * Creates an Asteroid with randomly chosen SizeClass
    */
    public Asteroid() {
        super(new Random().nextInt(2) == 0 ? SizeClass.SMALL
            : SizeClass.MEDIUM);
    }
    /**
    * This method checks if attack on Asteroid was successful
    * @return String describing if attack was successful
    */
    public String attacked() {
        return (Math.random() > DODGE_CHANCE ? this.getID() + " attacked."
            : this.getID() + " avoided attack.");
    }
    /**
    * This method checks if the Asteroid can be boarded
    * @return String describing if boarding was successful
    */
    public String boarded() {
        return (Math.random() < CAN_EMBARK ? this.getID() + " Boarded."
            : this.getID() + " could not be boarded.");
    }
    /**
    * This method returns the Asteroid's id and description of the planet
    * @return String representation of id and material composition of the planet
    */
    public String scanned() {
        return this.getID() + " is made of ... rocks?";
    }
    /**
    * This method returns the Asteroid's id and how it looks
    * @return String description of Asteroid
    */
    public String observed() {
        return this.getID() + " looks rough and rocky.";
    }
}
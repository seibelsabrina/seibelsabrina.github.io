/**
 * Represents objects you are able to attack
 * I did not collaborate on this assignment
 * @author Sabrina Seibel
 * @version 1.0
 */
public interface Attackable {
    double DODGE_CHANCE = .4;
    /**
    * This method checks if attack on object was successful
    * @return String describing if attack was successful
    */
    String attacked();
}
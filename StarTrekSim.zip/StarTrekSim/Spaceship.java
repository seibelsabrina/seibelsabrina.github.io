import java.util.Random;
/**
 * Represents a Spaceship object
 * I did not collaborate on this assignment
 * @author Sabrina Seibel
 * @version 1.0
 */
public class Spaceship extends AstronomicalObject implements Attackable,
    Embarkable {
    /**
    * Creates a Spaceship with randomly chosen SizeClass
    */
    public Spaceship() {
        super(new Random().nextInt(2) == 0 ? SizeClass.TEENY : SizeClass.TINY);
    }
    /**
    * This method checks if attack on Spaceship was successful
    * @return String describing if attack was successful
    */
    public String attacked() {
        return (Math.random() > DODGE_CHANCE ? this.getID() + " attacked."
            : this.getID() + " avoided attack.");
    }
    /**
    * This method checks if the Spaceship can be boarded
    * @return String describing if boarding was successful
    */
    public String boarded() {
        return (Math.random() < CAN_EMBARK ? this.getID() + " boarded."
            : this.getID() + " could not be boarded.");
    }
    /**
    * This method returns the Spaceship's id and how it looks
    * @return String description of Spaceship
    */
    public String observed() {
        return this.getID() + " looks small and lost out in the open.";
    }
}
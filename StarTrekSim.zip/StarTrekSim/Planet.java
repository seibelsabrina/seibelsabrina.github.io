import java.util.Random;
/**
 * Represents a Planet object
 * I did not collaborate on this assignment
 * @author Sabrina Seibel
 * @version 1.0
 */
public class Planet extends AstronomicalObject implements Embarkable,
    Scannable {

   /**
    * Creates a Planet with a randomly chosen SizeClass
    */
    public Planet() {
        super(new Random().nextInt(2) == 0 ? SizeClass.LARGISH
            : SizeClass.HUGE);
    }
   /**
    * This method returns the Planet's id and a description of it
    * @return String representation of id and material composition of the planet
    */
    public String scanned() {
        return this.getID() + " is made of gas.";
    }
    /**
    * This method checks if the Planet can be boarded
    * @return String describing if boarding was successful
    */
    public String boarded() {
        return (Math.random() < CAN_EMBARK ? this.getID() + " boarded."
            : this.getID() + " could not be boarded.");
    }
    /**
    * This method returns the Planet's id and how it looks
    * @return String description of Planet
    */
    public String observed() {
        return this.getID() +  " looks foggy in the distance.";
    }
}
/**
 * An enum that represents the ranking of the objects encountered
 * I did not collaborate on this assignment
 * @author Sabrina Seibel
 * @version 1.0
 */
public enum SizeClass {
    TEENY, TINY, SMALL, MEDIUM, LARGISH, HUGE, MASSIVE, GIGANTIC
}
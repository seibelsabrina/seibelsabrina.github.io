import java.util.Random;
/**
 * Represents a Star object
 * I did not collaborate on this assignment
 * @author Sabrina Seibel
 * @version 1.0
 */
public class Star extends AstronomicalObject implements Scannable {
   /**
    * Creates a Star with a randomly chosen SizeClass
    */
    public Star() {
        super(new Random().nextInt(2) == 0 ? SizeClass.MASSIVE
            : SizeClass.GIGANTIC);
    }

   /**
    * This method returns the Star's id and a description of it
    * @return String representation of id and description
    */
    public String scanned() {
        return this.getID() + " is made of cheese.";
    }

   /**
    * This method returns the Star's id and what it looks like
    * @return String description of Star
    */
    public String observed() {
        return this.getID() + " twinkles in the distance.";
    }

}
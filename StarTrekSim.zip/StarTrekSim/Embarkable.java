/**
 * Represents objects you are able to embark upon
 * I did not collaborate on this assignment
 * @author Sabrina Seibel
 * @version 1.0
 */
public interface Embarkable {
    double CAN_EMBARK = .7;
    /**
    * This method checks if boarding the Object was successful
    * @return String describing if attack was successful
    */
    String boarded();
}
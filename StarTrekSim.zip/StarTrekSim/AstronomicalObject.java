import java.util.Random;
/**
 * A class providing a basis for various things encountered in space
 * I did not collaborate on this assignment
 * @author Sabrina Seibel
 * @version 1.0
 */
//YOUR CODE HERE: Edit the class header to include all necessary information.
//Rember that you should not be able to create a new instance of this class.
public abstract class AstronomicalObject implements
    Comparable<AstronomicalObject> {
    /**
    * See implementations of AstronomicalObject
    */
    private String id;
    private SizeClass size;
    private static int totalcount = 0;
    /**
    * This method checks the SizeClass of the object
    * @return String description of SizeClass
    */
    public String observed() {
        if (size == SizeClass.MASSIVE) {
            return id + " is massive";
        } else if (size == SizeClass.GIGANTIC) {
            return id + " is gigantic";
        } else if (size == SizeClass.LARGISH) {
            return id + " is largish";
        } else if (size == SizeClass.HUGE) {
            return id + " is huge";
        } else if (size == SizeClass.SMALL) {
            return id + " is small";
        } else if (size == SizeClass.MEDIUM) {
            return id + " is medium";
        } else if (size == SizeClass.TEENY) {
            return id + " is teeny";
        } else if (size == SizeClass.TINY) {
            return id + " is tiny";
        } else {
            return "none";
        }
    }

    /**
    * This method returns the id of the object
    * @return id of object
    */
    public String toString() {
        return id;
    }

    /**
    * Creates an AstronomicalObject
    * @param size SizeClass of object
    */
    public AstronomicalObject(SizeClass size) {
        this.size = size;
        this.id = generateID();
        totalcount++;
    }

    /**
    * This method compares two AstronomicalObjects
    * @param a the AstronomicalObject compared to
    * @return an int comparison of the SizeClasses
    */
    public int compareTo(AstronomicalObject a) {
        return this.size.ordinal() - a.size.ordinal();
    }
    /**
    * This method returns the Object's id
    * @return String id
    */
    public String getID() {
        return id;
    }
    /**
    * This method returns the Object's size
    * @return SizeClass size
    */
    public SizeClass getSize() {
        return size;
    }
    /**
    * This method returns the total count of objects created
    * @return int number of AstronomicalObjects
    */
    public int getCount() {
        return totalcount;
    }

    //NOTE: DON'T CHANGE ANY CODE PAST THIS LINE
    /**
     * A method that generates a random ID based upon the type of the
     * object. You should use this each time the AstronomicalObject constructor
     * is called.
     *
     * @return The A randomly generated ID for the instance the method
     *         is called on
     */
    private String generateID() {
        Random randGen = new Random();
        String hex = Integer.toHexString(randGen.nextInt());
        return this.getClass().getName() + "-" + hex;
    }
}
